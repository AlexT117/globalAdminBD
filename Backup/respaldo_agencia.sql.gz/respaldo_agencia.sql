CREATE DATABASE IF NOT EXISTS agencia;

USE `agencia`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `color`;

CREATE TABLE `color` (
  `idcolor` int(11) NOT NULL,
  `nombre` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idcolor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `color` VALUES (1,"\tBlanco\t"),
(2,"\tGris \t"),
(3,"\tNegro\t"),
(4,"\tPlata\t"),
(5,"\tAzul\t"),
(6,"\tRojo\t"),
(7,"\tMarron\t"),
(8,"\tVerde\t"),
(9,"\tAmarillo\t"),
(10,"\tMagenta \t"),
(11,"\tPurpura \t"),
(12,"\tVerde Lima \t"),
(13,"\tturquesa\t"),
(14,"\tlila\t"),
(15,"Morado"),
(16,""),
(17,"rojo");


DROP TABLE IF EXISTS `comprador`;

CREATE TABLE `comprador` (
  `idComprador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellidoP` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellidoM` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `RFC` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idComprador`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `comprador` VALUES (1,"\tAlejandro\t","\tMendoza\t","\tAguilar\t","\tMEAA8305281H0\t","\t7713572465\t",1),
(2,"\tSofia\t","\tVargas \t","\tCervantes\t","\tVACS9811072D0\t","\t7718303743\t",1),
(3,"\tBenjamin\t","\tRios\t","\tSolis \t","\tRISB9005155T4\t","\t7714612908\t",1),
(4,"\tAriel\t","\tRojas\t","\tMontero\t","\tROMA8812241T4\t","\t7718561133\t",1),
(5,"\tAlfonso \t","\tContreras \t","\tEspinoza\t","\tCOEA8001217R0\t","\t7718900789\t",1),
(6,"\tLuis\t","\tFuentes\t","\tPeralta\t","\tFTPL750930560\t","\t7714563210\t",1),
(7,"\tVictor\t","\tHerrera\t","\tSepul\t","\tHESV7906120B5\t","\t7712005456\t",1),
(8,"\tDaniel\t","\tBravo\t","\tJime\t","\tBRJD800416GI5\t","\t7718536547\t",1),
(9,"\tLura \t","\tValencia\t","\tAguilar\t","\tVAAL981107G5D\t","\t7712310968\t",1),
(10,"\tCarlos \t","\tFavila \t","\tMelendez\t","\tFAMC8512316GD\t","\t7716091321\t",1),
(11,"\tAndrés\t","\tLópez\t","\tGarcía\t","\tLOGA890726ABC \t","\t7711234567\t",1),
(12,"\tSofía\t","\tMartínez\t","\tRodríguez\t","\tMARS000515DEF\t","\t7712345678\t",1),
(13,"\tMateo\t","\tGonzález\t","\tPérez\t","\tGOPE020731GHI \t","\t7713456789\t",1),
(14,"\tValentina\t","\tRodríguez\t","\tMorales\t","\tROMV110225JKL\t","\t7714567890\t",1),
(15,"\tNicolás\t","\tPérez\t","\tSánchez\t","\tPESN050628MNO\t","\t7715678901\t",1),
(16,"\tIsabella\t","\tFernández\t","\tLópez\t","\tFELI101214PQR\t","\t7716789012\t",1),
(17,"\tLucas\t","\tSánchez\t","\tGonzález\t","\tSAGL130916STU\t","\t7717890123\t",1),
(18,"\tCamila\t","\tRodríguez \t","\tPérez\t","\tROPC090723VWX\t","\t7718901234\t",1),
(19,"\tDiego\t","\tMartínez\t","\tRamírez\t","\tMARD080303YZA\t","\t7719012345\t",1),
(20,"\tValeria \t","\tRamírez\t","\tMorales\t","\tRAMV120505BCD \t","\t7710123456\t",1),
(21,"\tMatías\t","\tGarcía\t","\tHernández\t","\tGAHM060420EFG\t","\t7711234567\t",1),
(22,"\tElena\t","\tHernández\t","\tTorres \t","\tHETE071102HIJ \t","\t7712345678\t",1),
(23,"\tAlejandro\t","\tGonzález\t","\tDíaz\t","\tGODA041019KLM\t","\t7713456789\t",1),
(24,"\tRenata \t","\tTorres\t","\tVargas\t","\tTOVR030621NOP\t","\t7714567890\t",1),
(25,"\tJuan\t","\tDíaz\t","\tOrtega\t","\tDIOJ990807PQR \t","\t7715678901\t",1),
(26,"\tMartina\t","\t Ortega\t","\tNavarro\t","\tORNM070509STU\t","\t7716789012\t",1),
(27,"\tRafael\t","\tFernández\t","\tRíos \t","\tFERR110728VWX\t","\t7717890123\t",1),
(28,"\tVictoria\t","\tRíos\t","\tCastro\t","\tRICA120401YZA\t","\t7718901234\t",1),
(29,"\tLeonardo\t","\tSánchez\t","\tFlores\t","\tSAFL091103BCD\t","\t7719012345\t",1),
(30,"\tAmelia\t","\tFlores\t","\tMendoza\t","\tFOMA080615EFG\t","\t7710123456\t",1),
(31,"\tFrancisco\t","\tMartínez\t","\tPeralta\t","\tMAPF101214HIJ\t","\t7711234567\t",1),
(32,"\tNatalia\t","\tPeralta\t","\tBravo\t","\tPEBA050210KLM\t","\t7712345678\t",1),
(33,"\tJavier\t","\tRamírez\t","\tMiranda\t","\tRAMJ120731NOP\t","\t7713456789\t",1),
(34,"\tRenata\t","\tMiranda\t","\tAguilar\t","\tMIAR060525QR\t","\t7714567890\t",1),
(35,"\tDaniel\t","\tGonzález\t","\tCordero\t","\tGOCO100315STU\t","\t7715678901\t",1),
(36,"\tRenata\t","\tCordero\t","\tRojas\t","\tCORR110907VWX\t","\t7716789012\t",1),
(37,"\tGuillermo\t","\tSánchez\t","\tMora\t","\tSAMG090216YZA\t","\t7717890123\t",1),
(38,"\tIsabella\t","\tMora\t","\tRivas\t","\tMORI111221BCD\t","\t7718901234\t",1),
(39,"\tBruno\t","\tPérez\t","\tAcosta\t","\tPEAB070710EFG\t","\t7719012345\t",1),
(40,"\tAurora\t","\tAcosta\t","\tLeón\t","\tACLA101205HIJ\t","\t7710123456\t",1),
(41,"\tSebastián\t","\tLópez \t","\tEspinoza\t","\tLOES121004KLM\t","\t7711234567\t",1),
(42,"\tJimena\t","\tEspinoza\t","\tVarela\t","\t ESVJ110619NOP\t","\t7712345678\t",1),
(43,"\tManuel\t","\tGonzález\t","\tContreras\t","\t GOCM060803QR \t","\t7713457891\t",1),
(44,"\tCamila\t","\tContreras\t","\tOvalle\t","\t COCA070502STU \t","\t7714567890\t",1),
(45,"\tAlejandro\t","\tPérez\t","\tValencia\t","\t PEVA100414VWX \t","\t7715678901\t",1),
(46,"\tAmelia\t","\tValencia\t","\tPalma\t","\t VAPA090930YZA \t","\t7716789012\t",1),
(47,"\tTomás\t","\tMartínez\t","\tCorrea\t","\t MACO120522BCD \t","\t7717890123\t",1),
(48,"\tCatalina\t","\tCorrea\t","\tRoldán\t","\t CORC081123EFG \t","\t7718901234\t",1),
(49,"\tDiego\t","\tFernández\t","\tSepúlveda\t","\t FESD071012HIJ \t","\t7719012345\t",1),
(50,"\tValentina\t","\tSepúlveda\t","\tNavarrete\t","\t SENA090718KLM \t","\t7710123456\t",1),
(51,"\tLucas\t","\tRamírez\t","\tSilva\t","\t RASL121105NOP \t","\t7711234567\t",1),
(52,"\tIsabella\t","\tSilva\t","\tVillanueva\t","\t SIVI110317QR \t","\t7712345678\t",1),
(53,"\tNicolás\t","\tGonzález\t","\tOrellana\t","\t GOON080525STU \t","\t7713456789\t",1),
(54,"\tRenata\t","\tOrellana\t","\tIbarra\t","\t ORIR100202VWX \t","\t7714567890\t",1),
(55,"\tGabriel\t","\tLópez\t","\tLira\t","\t LOLG120619YZA \t","\t7715678901\t",1),
(56,"\tLucía\t","\tLira\t","\tRojas\t","\t LIRO100401BCD \t","\t7716789012\t",1),
(57,"\tAndrés\t","\tSánchez\t","\tVillanueva\t","\t SAVI090405EFG \t","\t7717890123\t",1),
(58,"\tValeria\t","\tVillanueva\t","\tPizarro\t","\t VAPI100220HIJ \t","\t7718901234\t",1),
(59,"\tMartín\t","\tRamírez\t","\tCáceres\t","\t RACA100705KLM \t","\t7719012345\t",1),
(60,"\tSofía\t","\tCáceres\t","\tOvalle\t","\t CAOS110813NOP \t","\t7710123456\t",1);


DROP TABLE IF EXISTS `marca`;

CREATE TABLE `marca` (
  `idMarca` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idMarca`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `marca` VALUES (1,"\tAcura\t"),
(2,"\tAlfa romeo\t"),
(3,"\tASTON MARTIN\t"),
(4,"\tAudi\t"),
(5,"\tBAIC\t"),
(6,"\tBentley\t"),
(7,"\tBMW\t"),
(8,"\tBUICK\t"),
(9,"\tCadilac\t"),
(10,"\tChevrolet\t"),
(11,"\tChrysler\t"),
(12,"\tDODGE\t"),
(13,"\tFerrari\t"),
(14,"\tFiat\t"),
(15,"\tFord\t"),
(16,"\tGMC\t"),
(17,"\tHonda\t"),
(18,"\tHyundai\t"),
(19,"\tInfiniti\t"),
(20,"\tJaguar\t"),
(21,"\tJAC\t"),
(22,"\tJeep\t"),
(23,"\tKIA\t"),
(24,"\tMazda\t"),
(25,"\tMercedes Benz\t"),
(26,"\tMitsubishi\t"),
(27,"\tNissan\t"),
(28,"\tPeugeot\t"),
(29,"\tRAM\t"),
(30,"\tRenault\t"),
(31,"\tSEAT\t"),
(32,"\tSubaru\t"),
(33,"\tSuzuki\t"),
(34,"\tTesla\t"),
(35,"\tToyota\t"),
(36,"\tVolkswagen\t"),
(37,"\tVolvo\t");


DROP TABLE IF EXISTS `seguro`;

CREATE TABLE `seguro` (
  `idSeguro` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descripcion` varchar(400) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idSeguro`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `seguro` VALUES (1,"\tCobertura de responsabilidad civil\t","\tte protegerá en gastos médicos a ocupantes o terceras personas que hayan resultado afectadas por el accidente, así como asesoría legal.\t"),
(2,"\tSeguro de auto cobertura limitada\t","\tte da derecho a todos aquellos gastos médicos, en cualquier circunstancia que haya ocurrido a bordo del automóvil, tanto las personas que viajaban en tu automóvil, así como a las que se encontraban en el vehículo con el cual surgió el percance.\t"),
(3,"\tSeguro de auto cobertura amplia \t","\tcontarás con servicios enfocados a mantener el cuidado de tú patrimonio pues va desde detalles mínimos como la reparación de tu auto, pagando un deducible marcado en la póliza de seguros de autos\t");


DROP TABLE IF EXISTS `tipodecompra`;

CREATE TABLE `tipodecompra` (
  `idTipoDeCompra` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idTipoDeCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipodecompra` VALUES (1,"\tContado \t"),
(2,"\tCredito \t");


DROP TABLE IF EXISTS `tipodevehiculo`;

CREATE TABLE `tipodevehiculo` (
  `idTipoDeVehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idTipoDeVehiculo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipodevehiculo` VALUES (1,"\tSedan \t"),
(2,"\tPick-up\t"),
(3,"\tTodoterreno\t"),
(4,"\tElectrico \t"),
(5,"\tSuper deportivo\t"),
(6,"\tSUV\t");


DROP TABLE IF EXISTS `traccion`;

CREATE TABLE `traccion` (
  `idTraccion` int(11) NOT NULL,
  `nombre` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idTraccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `traccion` VALUES (1,"\tDelantera\t"),
(2,"\tTrasera\t"),
(3,"\t4X4\t");


DROP TABLE IF EXISTS `vehiculo`;

CREATE TABLE `vehiculo` (
  `idVehiculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idMarca` int(11) NOT NULL,
  `precio` float DEFAULT NULL,
  `motor` varchar(35) COLLATE utf8_spanish_ci DEFAULT NULL,
  `idTraccion` int(11) NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `idTipoDeVehiculo` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idVehiculo`),
  KEY `fk_Vehiculo_Marca_idx` (`idMarca`),
  KEY `fk_Vehiculo_tipo de vehiculo1_idx` (`idTipoDeVehiculo`),
  KEY `fk_Vehiculo_Traccion1_idx` (`idTraccion`),
  CONSTRAINT `fk_Vehiculo_Marca` FOREIGN KEY (`idMarca`) REFERENCES `marca` (`idMarca`),
  CONSTRAINT `fk_Vehiculo_Traccion1` FOREIGN KEY (`idTraccion`) REFERENCES `traccion` (`idTraccion`),
  CONSTRAINT `fk_Vehiculo_tipo de vehiculo1` FOREIGN KEY (`idTipoDeVehiculo`) REFERENCES `tipodevehiculo` (`idTipoDeVehiculo`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `vehiculo` VALUES (1,4,666," \t2.0 L\t",1,"spiderman",1,0),
(2,2,2150000," \t2.9 L V8\t",1,"\tGIULIA\t",5,1),
(3,3,6700000," \tv8 biturvo\t",1,"\tDBX707\t",5,1),
(4,4,654900," \t2.5 L 5\t",1,"\ta3\t",1,1),
(5,5,465900," \t1.5L\t",3,"\tX35\t",3,1),
(6,6,5500000," \tw12 6.0 TSI\t",3,"\tContinental GT\t",5,1),
(7,7,1730000," \t4.4 v8 biturbo\t",3,"\tX6\t",6,1),
(8,8,585600," \t1.3 L\t",1,"\tEncore GX\t",1,1),
(9,9,2572400," \t6.8 L V8\t",3,"\tEscalade\t",5,1),
(10,10,1011900," \t5.3 L V8\t",3,"\tCheyene \t",2,1),
(11,11,889900," \t5.7 L V8\t",2,"\t300\t",1,1),
(12,12,1003100," \t5.7 L V8\t",2,"\tChallenger\t",5,1),
(13,13,1588790," \t4L V8 780vc\t",1,"\tSF90 Spider\t",5,1),
(14,14,355000," \t1.3L 4\t",3,"\tPulse\t",6,1),
(15,15,2124000," \t5.2L V8\t",3,"\tlobo raptor\t",3,1),
(16,16,2084000," \t6.2 L v8\t",3,"\tYukon\t",6,1),
(17,17,749900," \t2.0 L turbo\t",1,"\tType R\t",5,1),
(18,18,464200," \t1.6 L\t",1,"\tElantra\t",1,1),
(19,19,1056900," \t2.0 L turbo\t",2,"\tQ50\t",5,1),
(20,20,1469900," \tAJ V6\t",2,"\txf\t",5,1),
(21,21,462000," \t2.0 L 4\t",3,"\tFrison t8\t",6,1),
(22,22,1454900," \t3.6 L V6\t",3,"\tWangler\t",3,1),
(23,23,626900," \t2.0 L \t",3,"\tSportage\t",6,1),
(24,24,849900," \t2.5L Turbo\t",2,"\tCX-50\t",6,1),
(25,25,4106900," \t4.0L V8 biturbo\t",3,"\tG63\t",3,1),
(26,26,670000," \t2.4L turbo\t",2,"\tLancer\t",5,1),
(27,27,2791600," \tV6 doblre turbo\t",2,"\tGTR\t",5,1),
(28,28,585900," \t1.6 L\t",2,"\t3008\t",6,1),
(29,29,1135000," \t6.4 V8 \t",3,"\t2500\t",2,1),
(30,30,375000," \t1.6 L\t",3,"\tOroch\t",2,1),
(31,31,324900," \t1.6 L\t",2,"\tIbiza\t",1,1),
(32,32,336900," \t2.5 L \t",1,"\tImpreza\t",1,1),
(33,33,299990," \t1.2 L \t",3,"\tSwift\t",1,1),
(34,34,2629900," \tDual Traccion Integral\t",1,"\tmodel s\t",4,1),
(35,35,1407900," \t3.0 L turbo\t",2,"\tMK5\t",5,1),
(36,36,334490," \t1.6 L \t",1,"\tVirtus \t",1,1),
(37,37,1199900," \tWLTP\t",2,"\tEX30\t",4,1),
(38,25,1956940," \t3.0 L V6\t",3,"\tSuv\t",6,1),
(39,15,2575000," \t5.2 L V8\t",2,"\tMustang shelby\t",5,1),
(40,10,2003000," \t6.2 L V8\t",2,"\tCamaro ZL1\t",5,1),
(41,2,105600," \t2.9 L V6\t",2,"\tStelvio\t",5,1),
(42,30,230100," \t1.0 L 3\t",2,"\tKWID\t",6,1),
(43,37,799900," \t2.0 L 4\t",3,"\tCX40\t",6,1),
(44,29,2574900," \t6.2 supercargado\t",3,"\tTRX\t",2,1),
(45,31,555900," \tFR 190\t",1,"\tLeon\t",5,1),
(46,19,1045000," \t3.5 L V6\t",3,"\tQR60\t",6,1),
(47,23,715900," \t2.5L Turbo\t",3,"\tSorento\t",6,1),
(48,27,490000," \t2.5 L \t",3,"\t Frontier\t",2,1),
(49,33,235000," \tSJ410 de 1.984\t",3,"\tSamurai\t",3,1),
(50,34,881900," \tLong range performance\t",2,"\tModel 3\t",4,1),
(51,1,1100000," \t3.0 L V6\t",2,"\tTLX\t",5,1),
(52,14,515000," \t1.3 L Turbo \t",3,"\tFastback\t",6,1),
(53,17,605900," \t2.0 L turbo\t",2,"\tCivic sport\t",5,1),
(54,16,1168000," \t6.2 L V8\t",3,"\tSierra\t",2,1),
(55,4,1056000," \t3.0 L V6\t",3,"\tQ7 \t",6,1),
(56,6,250000," \t 4.0 L V8 \t",3,"\tBentayga\t",6,1),
(57,14,270000," \t1.0 L 4\t",1,"\tMobi\t",6,1),
(58,11,200600," \t2.4 L 4 \t",1,"\t200\t",1,1),
(59,22,1324000," \t5.7 L V8 \t",3,"\tCherokee\t",6,1),
(60,37,1505000," \t2.0 L 4\t",3,"\tCX90\t",6,1),
(61,9,6666,"v8 ",3,"SF90 ",2,0);


DROP TABLE IF EXISTS `vendedor`;

CREATE TABLE `vendedor` (
  `idVendedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellidoP` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellidoM` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idVendedor`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `vendedor` VALUES (1,"\tPedro \t","\tAguilar\t","\tPerez\t",1),
(2,"\tAlexis\t","\tTorres\t","\tRivera\t",1),
(3,"\tAna\t","\tGarcia\t","\tMartinez\t",1),
(4,"\tCarlos\t","\tHelecho\t","\tVargas\t",1),
(5,"\tMaria\t","\tSanches\t","\tSilva\t",1),
(6,"\tDiego\t","\tRamirez\t","\tMetro\t",1),
(7,"\tAndrea\t","\tGonzales\t","\tGuzman\t",1),
(8,"\tAlejandro\t","\tTorres\t","\tCortes \t",1),
(9,"\tAndres\t","\tDiaz\t","\tParedes\t",1),
(10,"\tGabriel\t","\tMorales\t","\tFuentes\t",1),
(11,"\tIsabel\t","\tHerrera\t","\tPeña\t",1),
(12,"\tGabriela\t","\tCastro\t","\tCarden\t",1),
(13,"\tManuel\t","\tOrtega\t","\tValencia\t",1),
(14,"\tJuan\t","\tTellez\t","\tSantander\t",1),
(15,"\tMariana \t","\tGomez\t","\tGarcia \t",1);


DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `idVentas` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `idComprador` int(11) NOT NULL,
  `comision` float DEFAULT NULL,
  `idVendedor` int(11) NOT NULL,
  `idTipoCompra` int(11) NOT NULL,
  `idSeguro` int(11) NOT NULL,
  `idVehiculo` int(10) unsigned NOT NULL,
  `idColor` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idVentas`),
  KEY `fk_Ventas_Comprador1_idx` (`idComprador`),
  KEY `fk_Ventas_Seguro1_idx` (`idSeguro`),
  KEY `fk_Ventas_Vendedor1_idx` (`idVendedor`),
  KEY `fk_Ventas_tipo de compra1_idx` (`idTipoCompra`),
  KEY `fk_Ventas_Vehiculo1_idx` (`idVehiculo`),
  KEY `fk_Ventas_color1_idx` (`idColor`),
  CONSTRAINT `fk_Ventas_Comprador1` FOREIGN KEY (`idComprador`) REFERENCES `comprador` (`idComprador`),
  CONSTRAINT `fk_Ventas_Seguro1` FOREIGN KEY (`idSeguro`) REFERENCES `seguro` (`idSeguro`),
  CONSTRAINT `fk_Ventas_Vehiculo1` FOREIGN KEY (`idVehiculo`) REFERENCES `vehiculo` (`idVehiculo`),
  CONSTRAINT `fk_Ventas_Vendedor1` FOREIGN KEY (`idVendedor`) REFERENCES `vendedor` (`idVendedor`),
  CONSTRAINT `fk_Ventas_color1` FOREIGN KEY (`idColor`) REFERENCES `color` (`idcolor`),
  CONSTRAINT `fk_Ventas_tipo de compra1` FOREIGN KEY (`idTipoCompra`) REFERENCES `tipodecompra` (`idTipoDeCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ventas` VALUES (1,"2023-01-07",37,34725,11,1,2,28,7,1),
(2,"2023-01-14",5,25390,5,2,1,51,12,1),
(3,"2023-01-22",19,45620,8,1,3,39,2,1),
(4,"2023-01-30",24,27810,12,2,2,16,10,1),
(5,"2023-02-06",12,38940,14,1,1,8,6,1),
(6,"2023-02-15",53,21950,7,2,3,33,4,1),
(7,"2023-02-24",44,49275,3,1,2,47,13,1),
(8,"2023-03-05",30,22750,9,1,3,12,8,1),
(9,"2023-03-12",58,41380,2,2,1,30,9,1),
(10,"2023-03-19",28,30560,6,1,2,3,1,1),
(11,"2023-03-28",41,40275,13,1,1,49,5,1),
(12,"2023-04-03",50,24890,10,2,3,19,3,1),
(13,"2023-04-11",33,35410,1,2,2,55,14,1),
(14,"2023-04-20",46,47680,4,1,3,41,11,1),
(15,"2023-04-27",14,29520,15,2,1,21,7,1),
(16,"2023-05-06",56,43890,6,2,3,52,4,1),
(17,"2023-05-14",21,23670,13,1,1,31,10,1),
(18,"2023-05-22",18,31740,8,1,2,17,12,1),
(19,"2023-05-30",26,44150,9,2,3,43,6,1),
(20,"2023-06-08",52,26480,1,2,1,38,9,1),
(21,"2023-06-17",49,37890,12,1,2,14,8,1),
(22,"2023-06-24",32,20980,2,2,3,25,3,1),
(23,"2023-07-02",38,48570,11,2,1,6,11,1),
(24,"2023-07-11",59,28260,7,1,2,44,5,1),
(25,"2023-07-19",16,42330,14,1,1,26,1,1),
(26,"2023-07-27",10,21560,5,2,3,15,2,1),
(27,"2023-01-05",31,33480,10,1,2,5,14,1),
(28,"2023-01-13",6,46720,4,2,3,7,13,1),
(29,"2023-01-21",35,25140,3,1,1,50,7,1),
(30,"2023-01-29",43,39120,15,2,2,56,6,1),
(31,"2023-02-07",7,22330,13,2,3,53,12,1),
(32,"2023-02-16",15,32870,2,1,1,2,4,1),
(33,"2023-02-25",34,20590,7,2,2,59,9,1),
(34,"2023-03-04",27,49950,6,2,1,9,10,1),
(35,"2023-03-13",55,24120,12,1,3,36,8,1),
(36,"2023-03-20",40,36890,8,2,2,23,1,1),
(37,"2023-03-29",48,23490,1,1,1,46,2,1),
(38,"2023-04-05",3,45430,14,1,3,58,5,1),
(39,"2023-04-13",22,27750,11,2,2,35,11,1),
(40,"2023-04-22",2,41760,5,2,3,11,14,1),
(41,"2023-04-29",54,31620,9,1,1,40,3,1),
(42,"2023-05-08",45,37240,4,2,2,13,13,1),
(43,"2023-05-16",20,22480,3,1,1,32,7,1),
(44,"2023-05-24",23,50000,10,2,3,10,4,1),
(45,"2023-06-01",9,26710,15,1,2,60,6,1),
(46,"2023-06-10",36,43170,6,2,3,48,12,1),
(47,"2023-06-18",11,29980,2,1,1,37,2,1),
(48,"2023-06-26",57,35690,1,1,3,29,9,1),
(49,"2023-07-04",8,20370,14,2,1,18,10,1),
(50,"2023-07-13",29,47950,13,1,2,4,8,1),
(51,"2023-07-21",25,28580,11,2,3,34,1,1),
(52,"2023-07-30",4,40680,8,1,1,1,14,1),
(53,"2023-01-03",60,23820,12,1,2,27,3,1),
(54,"2023-01-11",47,32050,3,2,1,22,11,1),
(55,"2023-01-19",1,48290,9,1,3,45,5,1),
(56,"2023-01-27",42,25920,7,2,2,20,13,1),
(57,"2023-02-05",39,42990,5,2,3,24,7,1),
(58,"2023-02-14",13,21280,10,1,1,54,4,1),
(59,"2023-02-23",51,39430,15,1,2,42,6,1),
(60,"2023-03-03",17,30120,4,2,1,57,12,1);


SET foreign_key_checks = 1;
